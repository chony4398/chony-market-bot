import asyncio
import os

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from shop.db import init_db, create_order, set_status

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN", "").strip()
SHOP_NAME = os.getenv("SHOP_NAME", "Digital Shop")
PAYMENT_DETAILS = os.getenv("PAYMENT_DETAILS", "Свяжитесь с администратором для оплаты.")
CURRENCY = os.getenv("CURRENCY", "EUR")
ADMIN_IDS = {
    int(item.strip())
    for item in os.getenv("ADMIN_IDS", "").split(",")
    if item.strip().isdigit()
}

# Замените примеры на законные цифровые товары или услуги.
PRODUCTS = [
    ("🎨 Дизайн", "Дизайн-услуга", "10"),
    ("📄 Шаблон", "Цифровой шаблон", "5"),
    ("🛠 Консультация", "Консультация", "15"),
]

dp = Dispatcher()

def catalog_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"{title} — {price} {CURRENCY}", callback_data=f"buy:{i}")]
        for i, (title, _, price) in enumerate(PRODUCTS)
    ])

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        f"Добро пожаловать в {SHOP_NAME}!\n\nВыберите цифровой товар или услугу:",
        reply_markup=catalog_keyboard(),
    )

@dp.callback_query(F.data.startswith("buy:"))
async def buy(callback: CallbackQuery, bot: Bot):
    try:
        index = int((callback.data or "").split(":", 1)[1])
        _, product, price = PRODUCTS[index]
    except (ValueError, IndexError):
        await callback.answer("Товар не найден.", show_alert=True)
        return

    order_id = create_order(
        callback.from_user.id,
        callback.from_user.username,
        product,
        f"{price} {CURRENCY}",
    )
    await callback.message.answer(
        f"Заказ №{order_id}: {product}\nЦена: {price} {CURRENCY}\n\n"
        f"Инструкция по оплате:\n{PAYMENT_DETAILS}\n\n"
        "После оплаты дождитесь подтверждения администратора. Не отправляйте пароли или коды входа."
    )

    for admin_id in ADMIN_IDS:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="Подтвердить", callback_data=f"paid:{order_id}"),
            InlineKeyboardButton(text="Отклонить", callback_data=f"reject:{order_id}"),
        ]])
        try:
            await bot.send_message(
                admin_id,
                f"Новый заказ №{order_id}\nПокупатель: {callback.from_user.id}"
                f" (@{callback.from_user.username or 'нет'})\nТовар: {product}\nЦена: {price} {CURRENCY}",
                reply_markup=keyboard,
            )
        except Exception:
            pass
    await callback.answer("Заказ создан")

@dp.callback_query(F.data.startswith(("paid:", "reject:")))
async def admin_order_action(callback: CallbackQuery):
    if callback.from_user.id not in ADMIN_IDS:
        await callback.answer("Нет доступа.", show_alert=True)
        return
    action, raw_id = (callback.data or "").split(":", 1)
    order_id = int(raw_id)
    status = "paid" if action == "paid" else "rejected"
    set_status(order_id, status)
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(f"Заказ №{order_id}: {status}")
    await callback.answer("Статус обновлён")

@dp.message(Command("admin"))
async def admin_help(message: Message):
    if message.from_user.id in ADMIN_IDS:
        await message.answer("Новые заказы приходят сюда автоматически. Подтверждайте их кнопками.")

async def main():
    if not TOKEN or TOKEN == "put_new_bot_token_here":
        raise RuntimeError("Укажите новый BOT_TOKEN в переменных окружения или файле .env")
    init_db()
    bot = Bot(TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
