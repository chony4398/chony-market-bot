import sqlite3
from pathlib import Path

DB_PATH = Path("shop.db")

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            product TEXT NOT NULL,
            price TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")

def create_order(user_id: int, username: str | None, product: str, price: str) -> int:
    with sqlite3.connect(DB_PATH) as con:
        cur = con.execute(
            "INSERT INTO orders (user_id, username, product, price) VALUES (?, ?, ?, ?)",
            (user_id, username, product, price),
        )
        return int(cur.lastrowid)

def set_status(order_id: int, status: str):
    with sqlite3.connect(DB_PATH) as con:
        con.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
